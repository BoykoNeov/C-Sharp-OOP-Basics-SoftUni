﻿namespace DefineAClassPerson
{
    class Launcher
    {
       public static void Main(string[] args)
        {
        }
    }
}